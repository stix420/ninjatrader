#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GexBot[] cacheGexBot;

		
		public GexBot GexBot(string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			return GexBot(Input, aPIKey, ticker, subscriptionType, nextFull, dotSize, greek, greekdotSize, widthFactor, gexAlingEjeProfile, direccionPerfil, xPosPerfil, withPerfil, convFactor, iRefresh, iCouchRefresh);
		}


		
		public GexBot GexBot(ISeries<double> input, string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			if (cacheGexBot != null)
				for (int idx = 0; idx < cacheGexBot.Length; idx++)
					if (cacheGexBot[idx].APIKey == aPIKey && cacheGexBot[idx].ticker == ticker && cacheGexBot[idx].SubscriptionType == subscriptionType && cacheGexBot[idx].nextFull == nextFull && cacheGexBot[idx].dotSize == dotSize && cacheGexBot[idx].Greek == greek && cacheGexBot[idx].GreekdotSize == greekdotSize && cacheGexBot[idx].WidthFactor == widthFactor && cacheGexBot[idx].GexAlingEjeProfile == gexAlingEjeProfile && cacheGexBot[idx].DireccionPerfil == direccionPerfil && cacheGexBot[idx].xPosPerfil == xPosPerfil && cacheGexBot[idx].withPerfil == withPerfil && cacheGexBot[idx].convFactor == convFactor && cacheGexBot[idx].iRefresh == iRefresh && cacheGexBot[idx].iCouchRefresh == iCouchRefresh && cacheGexBot[idx].EqualsInput(input))
						return cacheGexBot[idx];
			return CacheIndicator<GexBot>(new GexBot(){ APIKey = aPIKey, ticker = ticker, SubscriptionType = subscriptionType, nextFull = nextFull, dotSize = dotSize, Greek = greek, GreekdotSize = greekdotSize, WidthFactor = widthFactor, GexAlingEjeProfile = gexAlingEjeProfile, DireccionPerfil = direccionPerfil, xPosPerfil = xPosPerfil, withPerfil = withPerfil, convFactor = convFactor, iRefresh = iRefresh, iCouchRefresh = iCouchRefresh }, input, ref cacheGexBot);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GexBot GexBot(string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			return indicator.GexBot(Input, aPIKey, ticker, subscriptionType, nextFull, dotSize, greek, greekdotSize, widthFactor, gexAlingEjeProfile, direccionPerfil, xPosPerfil, withPerfil, convFactor, iRefresh, iCouchRefresh);
		}


		
		public Indicators.GexBot GexBot(ISeries<double> input , string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			return indicator.GexBot(input, aPIKey, ticker, subscriptionType, nextFull, dotSize, greek, greekdotSize, widthFactor, gexAlingEjeProfile, direccionPerfil, xPosPerfil, withPerfil, convFactor, iRefresh, iCouchRefresh);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GexBot GexBot(string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			return indicator.GexBot(Input, aPIKey, ticker, subscriptionType, nextFull, dotSize, greek, greekdotSize, widthFactor, gexAlingEjeProfile, direccionPerfil, xPosPerfil, withPerfil, convFactor, iRefresh, iCouchRefresh);
		}


		
		public Indicators.GexBot GexBot(ISeries<double> input , string aPIKey, string ticker, GexSubscriptionType subscriptionType, string nextFull, int dotSize, string greek, int greekdotSize, double widthFactor, GexAlingEjeProfile gexAlingEjeProfile, GexDirectionProfile direccionPerfil, int xPosPerfil, int withPerfil, float convFactor, int iRefresh, int iCouchRefresh)
		{
			return indicator.GexBot(input, aPIKey, ticker, subscriptionType, nextFull, dotSize, greek, greekdotSize, widthFactor, gexAlingEjeProfile, direccionPerfil, xPosPerfil, withPerfil, convFactor, iRefresh, iCouchRefresh);
		}

	}
}

#endregion
